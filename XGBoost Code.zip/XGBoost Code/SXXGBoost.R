#读取R包
library(xgboost)
library(dplyr)
library(lubridate)
library(data.table)
library(ggplot2)
library(ggpointdensity)
library(viridis)#turbo

#读取数据
trainpre1<-read.csv("D:\\Process\\XGBoost\\SXTable\\SX_Train_Data_Ex.csv", header=T, stringsAsFactors = FALSE)
summary(trainpre1)
#划分训练集和测试集
ind <- sample(2, nrow(trainpre1), replace = TRUE, prob = c(0.7, 0.3))
train <- trainpre1[ind == 1, ]
test <- trainpre1[ind == 2, ]
#随机数种子
set.seed(3000)
#训练集数据预处理
library(Matrix)
#数据转为矩阵
#自变量
train1<-data.matrix(train[,c(3:22)])
train2<-Matrix(train1,sparse=T)
#应变量
train_y<-as.numeric(train[,2])
train_y
#自变量应变量拼接
traindata<-list(data=train2,label=train_y)
#模型需要的xgb.DMatrix
dtrain<-xgb.DMatrix(data=traindata$data,label=traindata$label)

#测试集数据预处理
test1<-data.matrix(test[,c(3:22)])
test2<-Matrix(test1,sparse=T)
test_y<-as.numeric(test[,2])
testdata<-list(data=test2,label=test_y)
dtest<-xgb.DMatrix(data=testdata$data,label=testdata$label)

#建立模型
model_xgb <- xgboost(data = dtrain, 
                     booster = 'gbtree',
                     max_depth = 10, 
                     eta = 0.1, 
                     nround = 300, 
                     objective ='reg:squarederror', 
                     lambda = 0.5, 
                     alpha = 0.5, 
                     colsample_bytree = 0.5)
#max_depth（树的最大深度）:值为正整数，一般在3到10之间。增加该值会增加模型复杂度，并可能导致过拟合，减小该值可以提高模型泛化能力。
#eta（学习率）:值为0到1之间的实数，表示每次迭代中权重的更新幅度。较小的学习率能实现更好的收敛性和泛化能力。
#nround（迭代次数）:值为正整数。增加该值可能会提高模型性能，但也可能导致过拟合。
#objective指定目标函数，'reg:squarederror'，表示使用均方误差作为损失函数进行回归建模，用于大多数连续型预测问题，reg:logistic用于二元分类问题
#lambda（L2正则化项权重）:值为非负实数，用于控制模型复杂度。增大提高模型的泛化能力。
#alpha（L1正则化项权重）:值为非负实数，用于控制模型复杂度。增大提高模型的泛化能力。
#colsample_bytree（每棵树使用特征比例）:值为0到1之间的实数，表示每棵树使用的特征比例。增大可能出现过拟合。

#用测试集预测
pre <- predict(model_xgb,newdata=dtest)
#模型评估
summary(pre)
summary(test_y)


#画图
#创建数据框
comparison_data <- data.frame(actual = test_y, predicted = pre)
# 计算预测误差
comparison_data$error <- comparison_data$actual - comparison_data$predicted
# 绘制散点图
p1<-ggplot(comparison_data, aes(x = actual, y = predicted)) + geom_pointdensity(size = 1) +
  scale_color_viridis(option = "H" , 'density')  + 
  geom_abline(intercept = 0, slope = 1, color = "grey20",linewidth=1,lty="dashed") +  
  xlab("SHUII Actual Value") +  ylab("SUHII Predicted Value") +  
  theme(plot.title = element_text(size = 5))+  
  theme(text = element_text(family = "Times New Roman",size=5))+theme_bw()+
  theme(plot.title = element_text(size = 12, hjust = 0, vjust = 1))
p1
p21 = plot(p1, suppressprint=TRUE)
#输出图片
#ggplot2::ggsave("D:\\Process\\XGBoost\\SXTable\\SXplot.Tiff", plot=p21,width=8, height=6,dpi=800)

#测试集决定系数
test_r_squared <- 1 - sum((test_y - pre)^2) / sum((test_y - mean(pre))^2)
print(paste("Test R-squared:", test_r_squared))
#测试集RMSE
test_rmse <- sqrt(mean((pre - test_y))^2)
print(paste("Test RMSE:", test_rmse))

#用训练集预测
pretrain <- predict(model_xgb,newdata=dtrain)
#训练集决定系数
train_r_squared <- 1 - sum((train_y - pretrain)^2) / sum((train_y - mean(pretrain))^2)
print(paste("Train R-squared:", train_r_squared))
#训练集RMSE
train_rmse <- sqrt(mean((pretrain - train_y))^2)
print(paste("Train RMSE:", train_rmse))


# 读取新的CSV文件
new_data <- read.csv("D:\\Process\\XGBoost\\SXTable\\SX_Fishnet_2035Pre2_Ex.csv", header=T)

# 新数据预处理，提取自变量并转为矩阵
new_data_matrix <- data.matrix(new_data[, c(3:22)])  # 假设新CSV中的自变量和原始数据集一致，依然是第3列到第22列
new_data_sparse <- Matrix(new_data_matrix, sparse = T)

# 将新数据转为xgb.DMatrix格式，注意这里没有label，因为这是预测集
dnew <- xgb.DMatrix(data = new_data_sparse)

# 使用训练好的模型对新数据进行预测
new_predictions <- predict(model_xgb, newdata = dnew)

# 输出预测结果
print("New data predictions:")
print(new_predictions)

# 将预测结果保存到CSV文件中
new_data_with_predictions <- new_data
new_data_with_predictions$predicted_values <- new_predictions
write.csv(new_data_with_predictions, "D:\\Process\\XGBoost\\SXTable\\SX_Predict_20352.csv", row.names = FALSE)